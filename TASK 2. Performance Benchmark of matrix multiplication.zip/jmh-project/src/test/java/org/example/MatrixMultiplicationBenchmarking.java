package org.example;

import org.example.MatrixMultiplication;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.Random;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@Fork(1)
public class MatrixMultiplicationBenchmarking {

	@State(Scope.Thread)
	public static class Operands {
		private final int n = 16384;
		private final int percentageOfZeroElements = 90;
		private final double[][] a = new double[n][n];

		private final double[][] b = new double[n][n];

		@Setup
		public void setup() {
			Random random = new Random();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					a[i][j] = random.nextDouble();
					b[i][j] = random.nextDouble();
					if (random.nextInt(100) < percentageOfZeroElements) {
						a[i][j] = 0;
						b[i][j] = 0;
					}
				}
			}
		}
	}

	@State(Scope.Thread)
	public static class ResourceUsage {
		long totalMemoryUsed = 0;
		int iterations = 0;

		public void accumulate(long memoryUsed) {
			//memoryUsed/=1024*1024;
			//System.out.println("Memory Usage: " + memoryUsed + " MB");
			totalMemoryUsed += memoryUsed;
			iterations++;
		}

		@TearDown
		public void printAverageMemoryUsage() {
			if (iterations > 0) {
				double averageMemoryUsageMB = (double) totalMemoryUsed / ( 1024*1024*iterations);  // Convert bytes to MB
				System.out.println("Average Memory Usage: " + averageMemoryUsageMB + " MB");
			}
		}
	}

	@Warmup(iterations = 1, time = 1, timeUnit = TimeUnit.MILLISECONDS)
	@Benchmark
	public void standardMultiplication(Operands operands, ResourceUsage resourceUsage, Blackhole blackhole) {
		MatrixMultiplication matrixMultiplication = new MatrixMultiplication();
		benchmarkMethod(() -> {
			double[][] result = matrixMultiplication.execute(operands.a, operands.b);
			blackhole.consume(result);
		}, resourceUsage);
	}

	@Benchmark
	public void sparseMultiplication(Operands operands, ResourceUsage resourceUsage, Blackhole blackhole) {
		SparseMultiplication sparseMultiplication = new SparseMultiplication();
		benchmarkMethod(() -> {
			double[][] result = sparseMultiplication.execute(operands.a, operands.b, operands.percentageOfZeroElements);
			blackhole.consume(result);
		}, resourceUsage);
	}

	@Benchmark
	public void blockMatrixMultiplication(Operands operands, ResourceUsage resourceUsage, Blackhole blackhole) {
		BlockMatrixMultiplication blockMatrixMultiplication = new BlockMatrixMultiplication();
		benchmarkMethod(() -> {
			double[][] result = blockMatrixMultiplication.execute(operands.a, operands.b);
			blackhole.consume(result);
		}, resourceUsage);
	}

	public void benchmarkMethod(Runnable method, ResourceUsage resourceUsage) {
		System.gc();
		long beforeUsedMem = getUsedMemory();

		method.run();

		long afterUsedMem = getUsedMemory();
		long memoryUsed = afterUsedMem - beforeUsedMem;

		resourceUsage.accumulate(memoryUsed);
	}
	private long getUsedMemory() {
		Runtime runtime = Runtime.getRuntime();
		return runtime.totalMemory() - runtime.freeMemory();
	}
}
