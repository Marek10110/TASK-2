package org.example;

public class SparseMultiplication {
    public double[][] execute(double[][] a, double[][] b, double sparsityThreshold) {
        int n = a.length;
        double[][] c = new double[n][n];

        for (int i = 0; i < n; i++) {
            for (int k = 0; k < n; k++) {
                if (Math.abs(a[i][k]) < sparsityThreshold) continue;
                for (int j = 0; j < n; j++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return c;
    }
}
