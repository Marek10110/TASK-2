package org.example;

public class BlockMatrixMultiplication {

    private static final int BLOCK_SIZE = 64;

    public double[][] execute(double[][] a, double[][] b) {
        int n = a.length;
        double[][] result = new double[n][n];
        blockMultiply(a, b, result, n);
        return result;
    }

    private void blockMultiply(double[][] a, double[][] b, double[][] c, int n) {
        for (int i = 0; i < n; i += BLOCK_SIZE) {
            for (int j = 0; j < n; j += BLOCK_SIZE) {
                for (int k = 0; k < n; k += BLOCK_SIZE) {
                    multiplyBlock(a, b, c, i, j, k);
                }
            }
        }
    }

    private void multiplyBlock(double[][] a, double[][] b, double[][] c, int row, int col, int depth) {
        int endRow = Math.min(row + BLOCK_SIZE, a.length);
        int endCol = Math.min(col + BLOCK_SIZE, b.length);
        int endDepth = Math.min(depth + BLOCK_SIZE, b[0].length);

        for (int i = row; i < endRow; i++) {
            for (int k = depth; k < endDepth; k++) {
                double temp = a[i][k];
                for (int j = col; j < endCol; j++) {
                    c[i][j] += temp * b[k][j];
                }
            }
        }
    }
}
